const { ethers } = require("hardhat");

describe("Nwqe", () => {
  let owner;
  let addr1;
  let hardhat;
  let hardhatDeployed;

  beforeEach(async () => {
    [owner, addr1] = await ethers.getSigners();

    hardhat = await ethers.getContractFactory("Defi");

    hardhatDeployed = await hardhat.deploy();
    const blockNumBefore = await ethers.provider.getBlockNumber();
    const blockBefore = await ethers.provider.getBlock(blockNumBefore);
    const timestampBefore = blockBefore.timestamp;
    await hardhatDeployed.CreateStreamForEth(
      timestampBefore + 300,
      timestampBefore + 1,
      addr1.address,
      20,
      { value: ethers.utils.parseEther("10") }
    );
  });

  it("Calling BalanceOf", async () => {
    console.log(addr1.address);
    console.log(await hardhatDeployed.StreamContainer(0));
    await ethers.provider.send("evm_increaseTime", [20]);
    await ethers.provider.send("evm_mine");

    console.log(await hardhatDeployed.balanceOf(0, addr1.address));
  });
});
